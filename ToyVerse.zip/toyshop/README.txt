Setup Instructions
1. Download all project files.
2. Navigate to C:\xampp\htdocs on your local machine.
3. Create a new folder named toyverse.
4. Copy and paste all downloaded project files into the toyverse folder.
5. Open phpMyAdmin in your browser (typically at http://localhost/phpmyadmin).
6. Create a new database named toyverse_db.
7. Import the provided SQL file (e.g., toyverse.sql) into the toyverse_db database.

Make sure your XAMPP server (Apache & MySQL) is running before accessing the project via http://localhost/toyverse.

LOGIN INFO （FOR TESTING）
User: Franz13 Password: Franz#13

Description of What Each File Does:

index.php – Public homepage of the website.
about_us_logged_out.php – Displays website information for users who are not logged in.
login.php – User login form.
register.php – New user registration form.
homepage.php – Welcome page after successful login.
about.php – About Us page for logged-in users.
shop.php – Browse available products.
cart.php – View and manage items added to the cart.
checkout.php – Final order summary and payment processing.
receipt.php – Displays the transaction receipt after checkout.
account.php – Shows the logged-in user's account information.
register_complete.php – Displays user information after successful registration.
remove_item.php – Removes an item from the cart.
database.php – Manages database connection.
config.php – Contains database configuration settings.
update_item.php – Updates the quantity of an item in the cart.










